"""
a transfer learning algorithm based on TwoStageTrAdaBoostR2 from T1 temporal to T2 temporal 

# Algorithm principle��
"""
Stage 1.The source domain instance weight slowly decreases until it reaches a fixed value (determined by cv); Get the model with the lowest average error from CV - determine the instance weight
Stage 2.The weights of all source domain instances remain unchanged, and the weights of target domain instances are updated normally (Adaboost. R2);
Note:Only the prediction results generated in the second stage are stored and used to determine the output of the result model��
"""